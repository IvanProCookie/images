/* <!-- # TODO: # --> */
// (Maybe) add onEvents that bring you to the image (pages) for all the cursor images,
// Add a 'My Other Projects' page/screen with the Egyptian Multiplication thing,
// Add background music,
// (Maybe) add 88x31 buttons, posibly on that Egyptian page?

console.log('\n._______       _    .__    .____  \n|__. ._ \\     /.\\   |  \\   | ._ \\ \n   | | \\ \\   / _ \\__| . \\__| |_) |\n   | |  \\ \\_/ ___ \\_| |\\ \\_| .__/ \n.__| |___\\   /___\\ \\| |_\\ \\| |    \n|_________\\_/_____\\___|__\\___| ;3 \n');

console.log('Screen: intro.');

/* .ignore */
//setStyle("howItWorks", "image-rendering: pixelated;");
//setStyle('github', 'text-decoration: underline; text-decoration-color: #00f; cursor: pointer;');
//write('<a style="width: 84px; height: 16px; margin-left: 199px; margin-top: 331px;" href="https://ivanprocookie.github.io/iphotos/app" title="The Github responsory for this project.&#010;(Opens in a new tab >;3)">Github</a>');


    /* <!-- Custom Functions --> */
  /* Custom padEnd() padStart() functions cuz they don't exist in AppLab */
/* e.g; 'string'.padEnd(13, ' ') would return 'string       ' */
/* Also, 'string'.repeat() doesn't work, whih is why is use for() */
Object.prototype.padEnd=function(amount, char){
var pad = ''; var that = this.toString();
for (var i=0; i<amount - that.length; i++){pad=pad+char}
return that + pad;
};
Object.prototype.padStart=function(amount, char){
var pad = ''; var that = this.toString();
for (var i=0; i<amount - that.length; i++){pad=pad+char}
return pad + that;
};
  /* Pad Func [END] */

  /* Custom Transition Functions */
/* Meant for use with Light-Dark Mode but text didn't work properly */
/* Now mainly for use with changing screens *
function setTrans(id, property, ms){
  setStyle(id, "transition: " + property + " " + ms + "ms ease-in-out;");
}/**
function trans(id, property, color){
  setStyle(id, property + ": " + color + ";");
}/**/
function setTrans(id, ms){setStyle(id, "transition: opacity " + ms + "ms ease-in-out;");}
function unsetTrans(id){setStyle(id, "transition: none;");}
function trans(id, value){setStyle(id, "opacity: " + value + ";");}
  /* 🩵🩷🤍🩷🩵 Trans Functions [END] */
    /* <!-- Custom Functions [END] --> */


    /* <!-- Text Input Functions --> */
onEvent("input", "input", function(){
  //setText("text_input2", getText("text_input2").replace(/\d/gm,''));
  setText("input", getText("input").slice(0,13));
  inputChange();
});

/* The Character Map, contains all the characters my font supports, all made by me! */
/* And the Length Map which contains the dith of all characters, as a string */
var char_map = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '~', '`', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '_', '_', '-', '+', '=', '{OLD', '[', '}OLD', ']', '|', '\\', ':', ';', '"', '\'', '<', ',', '>', '.', '?', '/', ' ', '•', 'ω', 'å', '{', '}'];
var length_map = '534333443433554343434555554333443313325343333443533433433333334215555343223453332222131231323133315433';

/* Update/Change the Custom Font' Images when you type in the input box */
function inputChange(){
  //console.log(getText('input'));
  var input = getText('input');
  var string = input.padEnd(13, ' ');
  var lengths = [
    +length_map[char_map.indexOf(string[0])], +length_map[char_map.indexOf(string[1])], +length_map[char_map.indexOf(string[2])], +length_map[char_map.indexOf(string[3])], +length_map[char_map.indexOf(string[4])], +length_map[char_map.indexOf(string[5])], +length_map[char_map.indexOf(string[6])], +length_map[char_map.indexOf(string[7])], +length_map[char_map.indexOf(string[8])], +length_map[char_map.indexOf(string[9])], +length_map[char_map.indexOf(string[10])], +length_map[char_map.indexOf(string[11])], +length_map[char_map.indexOf(string[12])],
  ];
  //console.log(lengths);
    /* Change the Images, their Position and Width */
  for(var i = 0; i<13; i++){
    setImageURL("img" + (i+1).padStart(2, '0'), 'https://ivanprocookie.github.io/iphotos/app/characters/' + (light_mode ? 'white' : 'black') + '/' + char_map.indexOf(string[i]).padStart(3, '0')+'.png');
      // Ignore the 'Don't make functions within a loop' warning, it's okay here because it's a nameless function, `function(){...}`. \/ 
    setPosition("img" + (i+1).padStart(2, '0'), lengths.slice(0,i).reduce(function(t,c){return t + c*4 + 1*4}, 6), 326, lengths[i]*4, 32)}
} /* Text Input [END]   This is the formula --> 6 + 4(the sum from j equals 0, to i - 1, of 'lengths' sub j) + 4i    */
    /* <!-- Text Input Functions [END] --> */


    /* <!-- When Started Functions --> */
for(var i = 1; i<14; i++){
    /* Makes all letters blank*/
  setImageURL("img" + i.padStart(2, '0'), 'https://ivanprocookie.github.io/iphotos/app/characters/black/096.png');
    /* 4 Custom Cursors */
  setStyle("img" + i.padStart(2, '0'), "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans_rgb.png), auto;");
}
setText("img_cursors", "Cursors:");
setStyle('img_cursor-pentacle_black','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/alt/pentacle_black.png) 10 10, auto;');
setStyle('img_cursor-pentacle_trans','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/alt/pentacle_trans.png) 10 10, auto;');
setStyle('img_cursor-pentagram_black','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/alt/pentagram_black.png) 10 10, auto;');
setStyle('img_cursor-pentagram_trans','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/alt/pentagram_trans.png) 10 10, auto;');
/* image-rendering: pixelated; (Fail) *
setStyle('img_cursor-aT', 'image-rendering: pixelated;');
setStyle('img_cursor-ar', 'image-rendering: pixelated;');
setStyle('img_cursor-at', 'image-rendering: pixelated;');
setStyle('img_cursor-atr','image-rendering: pixelated;');
setStyle('img_cursor-pT', 'image-rendering: pixelated;');
setStyle('img_cursor-pr', 'image-rendering: pixelated;');
setStyle('img_cursor-pt', 'image-rendering: pixelated;');
setStyle('img_cursor-ptr','image-rendering: pixelated;');
setStyle('img_cursor-tT', 'image-rendering: pixelated;');
setStyle('img_cursor-tr', 'image-rendering: pixelated;');
setStyle('img_cursor-tt', 'image-rendering: pixelated;');
setStyle('img_cursor-ttr','image-rendering: pixelated;');
/* image-randering: pixelated [END] */
setStyle('img_cursor-pentacle_black', 'image-rendering: pixelated;');
setStyle('img_cursor-pentacle_trans', 'image-rendering: pixelated;');
setStyle('img_cursor-pentagram_black','image-rendering: pixelated;');
setStyle('img_cursor-pentagram_trans','image-rendering: pixelated;');
    /* <!-- When Started Functions [END] --> */


    /* <!-- This Doesn't work, but maybe i could fix it l8r --> */
// TITLE [SKIP4NOW]
/* prerequesits  *
setStyle("desc", "color: rgba(0, 0, 0, 1);");
setStyle("input", "color: rgba(0, 0, 0, 1);");
setTrans("intro",  "background-color", 1000);
setTrans("title_bg", "background-color", 1000);
setStyle("desc", "transition: color 1000ms ease-in-out;");
//setTrans("desc", "color", 1000);
setTrans("desc", "background-color", 1000);
setTrans("input", "color", 1000);
setTrans("input", "background-color", 1000);
setTrans("input_bg", "background-color", 1000);
setTrans("text_bg",  "background-color", 1000);
setTimeout(function(){setStyle("desc", "color: rgba(255, 255, 255, 1);")}, 1000);
    trans("intro",  "background-color", "#fff");
    trans("title_bg", "background-color", "#444");
    trans("desc", "color", "#fff");
    trans("desc", "background-color", "#444");
    trans("input", "color", "#000");
    trans("input", "background-color", "#fff");
    trans("input_bg", "background-color", "#444");
    trans("text_bg",  "background-color", "#444");
  /* <!-- TdwbmIcfIl? [END] --> */


    /* <!-- Light/Dark Mode --> */
var light_mode = false;
var mode = true;
onEvent("mode", "click", modeClick);
onEvent("mode2", "click", modeClick);
onEvent("mode3", "click", modeClick);
onEvent("mode4", "click", modeClick);
/* onEvent("mode", "click", function(){
  modeClick(false);
});
onEvent("mode2", "click", function(){
  modeClick(false);
});*/

function modeClick(){   //update){
                        //update = update == undefined ? false : update;
                        //console.log(update);
  if (mode){            //&& !update){
    light_mode = light_mode ? false : true;
    //setStyle("mode", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/arrow_trans.png),auto;");
    //setTimeout(function(){setStyle("mode", "cursor: default;")}, 800);
  }
  console.log('Light Mode: '+light_mode+';');
  setTimeout(inputChange, 500);
  if(light_mode & mode){          // Light Mode
      /* To stop repeated Mode clicking */
    mode = false;
    setTimeout(function(){
      mode = true;
    }, 1000); // 1 Second
    
      /* Mode Button */
    setImageURL("mode", "https://ivanprocookie.github.io/iphotos/app/night_day_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode", "https://ivanprocookie.github.io/iphotos/app/day.png");}, 1000);
      /* Mode2 Button */
    setImageURL("mode2", "https://ivanprocookie.github.io/iphotos/app/night_day_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode2", "https://ivanprocookie.github.io/iphotos/app/day.png");}, 1000);
      /* Mode3 Button */
    setImageURL("mode3", "https://ivanprocookie.github.io/iphotos/app/night_day_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode3", "https://ivanprocookie.github.io/iphotos/app/day.png");}, 1000);
      /* Mode4 Button */
    setImageURL("mode4", "https://ivanprocookie.github.io/iphotos/app/night_day_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode4", "https://ivanprocookie.github.io/iphotos/app/day.png");}, 1000);

      /* intro Background */
    setProperty("intro", "background-color", '#000');
    setTimeout(function(){setProperty("intro", "background-color", '#444');}, 250);
    setTimeout(function(){setProperty("intro", "background-color", '#7f7f7f');}, 500);
    setTimeout(function(){setProperty("intro", "background-color", '#fff');}, 750);
      /* how_it_works Background */
    setProperty("how_it_works", "background-color", '#000');
    setTimeout(function(){setProperty("how_it_works", "background-color", '#444');}, 250);
    setTimeout(function(){setProperty("how_it_works", "background-color", '#7f7f7f');}, 500);
    setTimeout(function(){setProperty("how_it_works", "background-color", '#fff');}, 750);
      /* spritess Background */
    setProperty("spritess", "background-color", '#000');
    setTimeout(function(){setProperty("spritess", "background-color", '#444');}, 250);
    setTimeout(function(){setProperty("spritess", "background-color", '#7f7f7f');}, 500);
    setTimeout(function(){setProperty("spritess", "background-color", '#fff');}, 750);
      /* cursorss Background */
    setProperty("cursorss", "background-color", '#000');
    setTimeout(function(){setProperty("cursorss", "background-color", '#444');}, 250);
    setTimeout(function(){setProperty("cursorss", "background-color", '#7f7f7f');}, 500);
    setTimeout(function(){setProperty("cursorss", "background-color", '#fff');}, 750);
    
      /* Title */
    setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_black.png");
    setTimeout(function(){setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 250);
    setTimeout(function(){setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 500);
    setTimeout(function(){setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_white.png");}, 750);
      /* Title2 */
    setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_black.png");
    setTimeout(function(){setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 250);
    setTimeout(function(){setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 500);
    setTimeout(function(){setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_white.png");}, 750);
      /* Title3 */
    setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_black.png");
    setTimeout(function(){setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 250);
    setTimeout(function(){setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 500);
    setTimeout(function(){setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_white.png");}, 750);
      /* Title4 */
    setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_black.png");
    setTimeout(function(){setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 250);
    setTimeout(function(){setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 500);
    setTimeout(function(){setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_white.png");}, 750);
    
      /* Title Background */
    setTimeout(function(){setProperty("title_bg", "background-color", '#444');}, 500);
      /* Title2 Background */
    setTimeout(function(){setProperty("title_bg2", "background-color", '#444');}, 500);
      /* Title3 Background */
    setTimeout(function(){setProperty("title_bg3", "background-color", '#444');}, 500);
      /* Title4 Background */
    setTimeout(function(){setProperty("title_bg4", "background-color", '#444');}, 500);
    
      /* Description Text Color & Background */
    setTimeout(function(){setProperty("desc", "text-color", '#fff');}, 500);
    setTimeout(function(){setProperty("desc", "background-color", '#444');}, 500);

      /* Explanation Text Color & Background */
    setTimeout(function(){setProperty("explanation", "text-color", '#fff');}, 500);
    setTimeout(function(){setProperty("explanation", "background-color", '#444');}, 500);

      /* img_cursors Text Color & Background */
    setTimeout(function(){setProperty("img_cursors", "text-color", '#fff');}, 500);
    setTimeout(function(){setProperty("img_cursors", "background-color", '#444');}, 500);
    
      /* howItWorks-> */
    setTimeout(function(){setImageURL("howItWorks", "https://ivanprocookie.github.io/iphotos/app/howItWorks_light.png");}, 500);
      /* sprites-> */
    setTimeout(function(){setImageURL("sprites", "https://ivanprocookie.github.io/iphotos/app/sprites_light.png");}, 500);
      /* cursors-> */
    setTimeout(function(){setImageURL("cursors", "https://ivanprocookie.github.io/iphotos/app/cursors_light.png");}, 500);
      /* <-back */
    setTimeout(function(){setImageURL("back", "https://ivanprocookie.github.io/iphotos/app/back_light.png");}, 500);
    
      /* Input Text Color & Background */
    setTimeout(function(){setProperty("input", "text-color", '#000');}, 500);
    setProperty("input", "background-color", '#000');
    setTimeout(function(){setProperty("input", "background-color", '#444');}, 250);
    setTimeout(function(){setProperty("input", "background-color", '#7f7f7f');}, 500);
    setTimeout(function(){setProperty("input", "background-color", '#fff');}, 750);
      /* Input_bg Background */
    setTimeout(function(){setProperty("input_bg", "background-color", '#444');}, 500);
    
      /* text_bg Background */
    setTimeout(function(){setProperty("text_bg", "background-color", '#444');}, 500);
    
      /* Scene Selector 3000 */
    setTimeout(function(){setImageURL("scene_selector_3000", "https://ivanprocookie.github.io/iphotos/app/scene_images/ss3k/set_light.png");}, 500);
      /* Math :3 */
    setTimeout(function(){setImageURL("6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i", "https://ivanprocookie.github.io/iphotos/app/scene_images/6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i_light.png");}, 500);
    
      /* Sprite-Sheet */
    setTimeout(function(){setImageURL("spritesheet", "https://ivanprocookie.github.io/iphotos/app/character_spritesheet_graphic_light.png");}, 500);
    
      /* Cursors */
    setTimeout(function(){
      setImageURL('img_cursor-aT', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_TRANS.png');
      setImageURL('img_cursor-ar', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_rgb.png');
      setImageURL('img_cursor-at', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans.png');
      setImageURL('img_cursor-atr','https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans_rgb.png');
      setImageURL('img_cursor-pT', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_TRANS.png');
      setImageURL('img_cursor-pr', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_rgb.png');
      setImageURL('img_cursor-pt', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans.png');
      setImageURL('img_cursor-ptr','https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans_rgb.png');
      setImageURL('img_cursor-tT', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/text_TRANS.png');
      setImageURL('img_cursor-tr', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/text_rgb.png');
      setImageURL('img_cursor-tt', 'https://ivanprocookie.github.io/iphotos/app/cursors/white/text_trans.png');
      setImageURL('img_cursor-ttr','https://ivanprocookie.github.io/iphotos/app/cursors/white/text_trans_rgb.png');
    }, 500);
    
      /* 4 Custom Cursors */
    setTimeout(function(){cursors(true);}, 500);
    
      /* Transition */
    screens.forEach(function(e){
      setStyle("transition-"+e, "background-color: #fff; opacity: 0;");
    });
    
  /* Light Mode [END] */
  }else if (!light_mode & mode){  // Dark Mode
      /* To stop repeated Mode clicking */
    mode = false;
    setTimeout(function(){
      mode = true;
    }, 1000);
    
      /* Mode Button */
    setImageURL("mode", "https://ivanprocookie.github.io/iphotos/app/day_night_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode", "https://ivanprocookie.github.io/iphotos/app/night.png");}, 1000);
      /* Mode2 Button */
    setImageURL("mode2", "https://ivanprocookie.github.io/iphotos/app/day_night_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode2", "https://ivanprocookie.github.io/iphotos/app/night.png");}, 1000);
      /* Mode3 Button */
    setImageURL("mode3", "https://ivanprocookie.github.io/iphotos/app/day_night_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode3", "https://ivanprocookie.github.io/iphotos/app/night.png");}, 1000);
      /* Mode4 Button */
    setImageURL("mode4", "https://ivanprocookie.github.io/iphotos/app/day_night_20fps_nl.gif");
    setTimeout(function(){setImageURL("mode4", "https://ivanprocookie.github.io/iphotos/app/night.png");}, 1000);
    
      /* intro Background */
    setProperty("intro", "background-color", '#fff');
    setTimeout(function(){setProperty("intro", "background-color", '#7f7f7f');}, 250);
    setTimeout(function(){setProperty("intro", "background-color", '#444');}, 500);
    setTimeout(function(){setProperty("intro", "background-color", '#000');}, 750);
      /* how_it_works Background */
    setProperty("how_it_works", "background-color", '#fff');
    setTimeout(function(){setProperty("how_it_works", "background-color", '#7f7f7f');}, 250);
    setTimeout(function(){setProperty("how_it_works", "background-color", '#444');}, 500);
    setTimeout(function(){setProperty("how_it_works", "background-color", '#000');}, 750);
      /* spritess Background */
    setProperty("spritess", "background-color", '#fff');
    setTimeout(function(){setProperty("spritess", "background-color", '#7f7f7f');}, 250);
    setTimeout(function(){setProperty("spritess", "background-color", '#444');}, 500);
    setTimeout(function(){setProperty("spritess", "background-color", '#000');}, 750);
      /* cursorss Background */
    setProperty("cursorss", "background-color", '#fff');
    setTimeout(function(){setProperty("cursorss", "background-color", '#7f7f7f');}, 250);
    setTimeout(function(){setProperty("cursorss", "background-color", '#444');}, 500);
    setTimeout(function(){setProperty("cursorss", "background-color", '#000');}, 750);
    
      /* Title */
    setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_white.png");
    setTimeout(function(){setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 250);
    setTimeout(function(){setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 500);
    setTimeout(function(){setImageURL("title", "https://ivanprocookie.github.io/iphotos/app/title_black.png");}, 750);
      /* Title2 */
    setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_white.png");
    setTimeout(function(){setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 250);
    setTimeout(function(){setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 500);
    setTimeout(function(){setImageURL("title2", "https://ivanprocookie.github.io/iphotos/app/title_black.png");}, 750);
      /* Title3 */
    setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_white.png");
    setTimeout(function(){setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 250);
    setTimeout(function(){setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 500);
    setTimeout(function(){setImageURL("title3", "https://ivanprocookie.github.io/iphotos/app/title_black.png");}, 750);
      /* Title4 */
    setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_white.png");
    setTimeout(function(){setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_light.png");}, 250);
    setTimeout(function(){setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_dark.png");}, 500);
    setTimeout(function(){setImageURL("title4", "https://ivanprocookie.github.io/iphotos/app/title_black.png");}, 750);
    
      /* Title Background */
    setTimeout(function(){setProperty("title_bg", "background-color", '#7f7f7f');}, 500);
      /* Title2 Background */
    setTimeout(function(){setProperty("title_bg2", "background-color", '#7f7f7f');}, 500);
      /* Title3 Background */
    setTimeout(function(){setProperty("title_bg3", "background-color", '#7f7f7f');}, 500);
      /* Title4 Background */
    setTimeout(function(){setProperty("title_bg4", "background-color", '#7f7f7f');}, 500);
    
      /* Description Text Color & Background */
    setTimeout(function(){setProperty("desc", "text-color", '#000');}, 500);
    setTimeout(function(){setProperty("desc", "background-color", '#7f7f7f');}, 500);
    
      /* Explanation Text Color & Background */
    setTimeout(function(){setProperty("explanation", "text-color", '#000');}, 500);
    setTimeout(function(){setProperty("explanation", "background-color", '#7f7f7f');}, 500);
    
      /* img_cursors Text Color & Background */
    setTimeout(function(){setProperty('img_cursors', "text-color", '#000');}, 500);
    setTimeout(function(){setProperty('img_cursors', "background-color", '#7f7f7f');}, 500);
    
      /* howItWorks-> */
    setTimeout(function(){setImageURL("howItWorks", "https://ivanprocookie.github.io/iphotos/app/howItWorks_dark.png");}, 500);
      /* sprites-> */
    setTimeout(function(){setImageURL("sprites", "https://ivanprocookie.github.io/iphotos/app/sprites_dark.png");}, 500);
      /* cursors-> */
    setTimeout(function(){setImageURL("cursors", "https://ivanprocookie.github.io/iphotos/app/cursors_dark.png");}, 500);
      /* <-back */
    setTimeout(function(){setImageURL("back", "https://ivanprocookie.github.io/iphotos/app/back_dark.png");}, 500);
    
      /* Input Text Color & Background */
    setTimeout(function(){setProperty("input", "text-color", '#fff');}, 500);
    setProperty("input", "background-color", '#fff');
    setTimeout(function(){setProperty("input", "background-color", '#7f7f7f');}, 250);
    setTimeout(function(){setProperty("input", "background-color", '#444');}, 500);
    setTimeout(function(){setProperty("input", "background-color", '#000');}, 750);
      /* Input_bg Background */
    setTimeout(function(){setProperty("input_bg", "background-color", '#7f7f7f');}, 500);
    
      /* Text Background */
    setTimeout(function(){setProperty("text_bg", "background-color", '#7f7f7f');}, 500);
    
      /* Scene Selector 3000 */
    setTimeout(function(){setImageURL("scene_selector_3000", "https://ivanprocookie.github.io/iphotos/app/scene_images/ss3k/set_dark.png");}, 500);
      /* Math ;3 */
    setTimeout(function(){setImageURL("6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i", "https://ivanprocookie.github.io/iphotos/app/scene_images/6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i_dark.png");}, 500);
    
      /* Sprite-Sheet */
    setTimeout(function(){setImageURL("spritesheet", "https://ivanprocookie.github.io/iphotos/app/character_spritesheet_graphic_dark.png");}, 500);
    
      /* Cursors */
    setTimeout(function(){
      setImageURL('img_cursor-aT', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_TRANS.png');
      setImageURL('img_cursor-ar', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_rgb.png');
      setImageURL('img_cursor-at', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_trans.png');
      setImageURL('img_cursor-atr','https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_trans_rgb.png');
      setImageURL('img_cursor-pT', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_TRANS.png');
      setImageURL('img_cursor-pr', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_rgb.png');
      setImageURL('img_cursor-pt', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans.png');
      setImageURL('img_cursor-ptr','https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans_rgb.png');
      setImageURL('img_cursor-tT', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/text_TRANS.png');
      setImageURL('img_cursor-tr', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/text_rgb.png');
      setImageURL('img_cursor-tt', 'https://ivanprocookie.github.io/iphotos/app/cursors/black/text_trans.png');
      setImageURL('img_cursor-ttr','https://ivanprocookie.github.io/iphotos/app/cursors/black/text_trans_rgb.png');
    }, 500);
    
      /* 4 Custom Cursors */
    setTimeout(cursors, 500);
      /* Transition */
    screens.forEach(function(e){setStyle("transition-"+e, "background-color: #000; opacity: 0;");});
    
  /* Dark Mode [END] */
  }
}
    /* <!-- Light/Dark Mode [END] --> */


    /*## .IGNORE ##*/
/* Next Screen (howItWorks-btn => how_it_works-scrn)*
setStyle("transition-intro", "pointer-events: none;");
setStyle("transition-how_it_works", "pointer-events: none;");
//setStyle("transition-sprites", "pointer-events: none;");
trans("transition-how_it_works", "background-color", "#000");
trans("transition-sprites", "background-color", "#000");
setTrans("transition-intro", "background-color", "500");
setStyle("transition-how_it_works", "background-color", "500");
/**
  trans("transition-intro", "background-color", "rgba(0, 0, 0, 1)");
  setTimeout(function(){
    setScreen("how_it_works");
    trans("transition-how_it_works", "background-color", "rgba(0, 0, 0, 0)");
    modeClick(true);
    console.log('Screen: how_it_works.');
}, 500);*/
//setStyle("transition-intro", "pointer-events: none;");
//setStyle("transition-how_it_works", "pointer-events: none;");
    /*## .IGNORE [END] ##*/


    /* <!-- Screen Switching --> */
var screens = ['intro', 'how_it_works', 'spritess', 'cursorss'];
screens.forEach(function(e){
  setStyle("transition-"+e, "pointer-events: none; background-color: #000; opacity: 0;");
}); setStyle("transition-how_it_works", "z-index: 67;");

function screen(scrn, scrn_){
  // untrans_=>settran_=>trans=>settrans=>settimeout(trans=>screen_=>untrans_=>unsetrans=>unsettrans_)
  trans('transition-'+screens[scrn_], 1);
  setTrans('transition-'+screens[scrn_], 500);
  trans('transition-'+screens[scrn], 0);
  setTrans('transition-'+screens[scrn], 500);
  trans('transition-'+screens[scrn], 1);
  setTimeout(function(){
    setScreen(screens[scrn_]);  //setScreen("how_it_works");
    trans('transition-'+screens[scrn_], 0);
    console.log('Screen: how_it_works.');
  }, 500);
  setTimeout(function(){
    unsetTrans('transition-'+screens[scrn]);
    unsetTrans('transition-'+screens[scrn_]);
  }, 1000);
}

onEvent("howItWorks", "click", function(){screen(0,1);});
onEvent("sprites", "click", function(){screen(1,2);});
onEvent("cursors", "click", function(){screen(2,3);});
onEvent("back", "click", function(){screen(3,0);});

onEvent("title", "click", function(){screen(0,0);});
onEvent("title2", "click", function(){screen(1,0);});
onEvent("title3", "click", function(){screen(2,0);});
onEvent("title4", "click", function(){screen(3,0);});
    /* <!-- Screen Switching [END] --> */


    /* <!-- Custom Cursors --> (Made By Me! :3) */
/* These also get updated by mode */
// Offsets just FYI: arrow: 0,0; text: 5,7; pointer: 6,0
function cursors(light){
  if(light){  /* Light Mode */
    /* Screens */
  setStyle("intro", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_rgb.png), auto;");
  setStyle("how_it_works", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_rgb.png), auto;");
  setStyle("spritess", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_rgb.png), auto;");
  setStyle("cursorss", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_rgb.png), auto;");
    /* Title */
  setStyle("title", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans_rgb.png) 6 0, auto;");
  setStyle("title2", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans_rgb.png) 6 0, auto;");
  setStyle("title3", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans_rgb.png) 6 0, auto;");
  setStyle("title4", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans_rgb.png) 6 0, auto;");
    /* Modes */
  setStyle("mode", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_TRANS.png) 6 0, auto;");
  setStyle("mode2", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_TRANS.png) 6 0, auto;");
  setStyle("mode3", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_TRANS.png) 6 0, auto;");
  setStyle("mode4", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_TRANS.png) 6 0, auto;");
    /* Text-Areas and Inputs */
  setStyle("desc", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_rgb.png) 5 7, auto;");
  setStyle("input", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_rgb.png) 5 7, auto;");
  setStyle("text_bg", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_trans_rgb.png), auto;");
  setStyle("explanation", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_rgb.png) 5 7, auto;");
    /* Screen Button */
  setStyle("howItWorks", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_rgb.png) 6 0, auto;");
  setStyle("sprites", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_rgb.png) 6 0, auto;");
  setStyle("cursors", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_rgb.png) 6 0, auto;");
  setStyle("back", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_rgb.png) 6 0, auto;");
    /* How-It-Works & Sprites */
  setStyle("slider", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_trans.png), auto;");
  setStyle("cursor", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_rgb.png) 5 7, auto;");
  setStyle("scene_selector_3000", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans.png) 6 0, auto;");
  setStyle("github", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_rgb.png) 6 0, auto;");
    /* Cursorss */
  setStyle('img_cursor-aT', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_TRANS.png), auto;');
  setStyle('img_cursor-ar', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_rgb.png), auto;');
  setStyle('img_cursor-at', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_trans.png), auto;');
  setStyle('img_cursor-atr','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_trans_rgb.png), auto;');
  setStyle('img_cursor-pT', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_TRANS.png) 6 0, auto;');
  setStyle('img_cursor-pr', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_rgb.png) 6 0, auto;');
  setStyle('img_cursor-pt', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans.png) 6 0, auto;');
  setStyle('img_cursor-ptr','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/pointer_trans_rgb.png) 6 0, auto;');
  setStyle('img_cursor-tT', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_TRANS.png) 5 7, auto;');
  setStyle('img_cursor-tr', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_rgb.png) 5 7, auto;');
  setStyle('img_cursor-tt', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_trans.png) 5 7, auto;');
  setStyle('img_cursor-ttr','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/text_trans_rgb.png) 5 7, auto;');
    /* Character Images */
  for(var w = 1; w<14; w++){setStyle("img" + w.padStart(2, '0'), "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/black/arrow_trans_rgb.png), auto;")}
  }else{  /* Dark Mode */
    /* Screens */
  setStyle("intro", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_rgb.png), auto;");
  setStyle("how_it_works", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_rgb.png), auto;");
  setStyle("spritess", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_rgb.png), auto;");
  setStyle("cursorss", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_rgb.png), auto;");
    /* Title */
  setStyle("title", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans_rgb.png) 6 0, auto;");
  setStyle("title2", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans_rgb.png) 6 0, auto;");
  setStyle("title3", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans_rgb.png) 6 0, auto;");
  setStyle("title4", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans_rgb.png) 6 0, auto;");
    /* Modes */
  setStyle("mode", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_TRANS.png) 6 0, auto;");
  setStyle("mode2", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_TRANS.png) 6 0, auto;");
  setStyle("mode3", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_TRANS.png) 6 0, auto;");
  setStyle("mode4", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_TRANS.png) 6 0, auto;");
    /* Text-Areas and Inputs */
  setStyle("desc", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_rgb.png) 5 7, auto;");
  setStyle("input", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_rgb.png) 5 7, auto;");
  setStyle("text_bg", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans_rgb.png), auto;");
  setStyle("explanation", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_rgb.png) 5 7, auto;");
    /* Screen Button */
  setStyle("howItWorks", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_rgb.png) 6 0, auto;");
  setStyle("sprites", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_rgb.png) 6 0, auto;");
  setStyle("cursors", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_rgb.png) 6 0, auto;");
  setStyle("back", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_rgb.png) 6 0, auto;");
    /* How-It-Works & Sprites */
  setStyle("slider", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans.png), auto;");
  setStyle("cursor", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_rgb.png) 5 7, auto;");
  setStyle("scene_selector_3000", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans.png) 6 0, auto;");
  setStyle("github", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_rgb.png) 6 0, auto;");
    /* Cursorss */
  setStyle('img_cursor-aT', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_TRANS.png), auto;');
  setStyle('img_cursor-ar', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_rgb.png), auto;');
  setStyle('img_cursor-at', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans.png), auto;');
  setStyle('img_cursor-atr','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans_rgb.png), auto;');
  setStyle('img_cursor-pT', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_TRANS.png) 6 0, auto;');
  setStyle('img_cursor-pr', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_rgb.png) 6 0, auto;');
  setStyle('img_cursor-pt', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans.png) 6 0, auto;');
  setStyle('img_cursor-ptr','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/pointer_trans_rgb.png) 6 0, auto;');
  setStyle('img_cursor-tT', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_TRANS.png) 5 7, auto;');
  setStyle('img_cursor-tr', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_rgb.png) 5 7, auto;');
  setStyle('img_cursor-tt', 'cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_trans.png) 5 7, auto;');
  setStyle('img_cursor-ttr','cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_trans_rgb.png) 5 7, auto;');
    /* Character Images */
  for(var b = 1; b<14; b++){setStyle("img" + b.padStart(2, '0'), "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/arrow_trans_rgb.png), auto;")}
  }
  //setStyle("slider", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/alt/pentagram_trans.png), auto;");
  //setStyle("cursor", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_rgb.png) 5 7, auto;");
} //setStyle("title", "cursor: url(https://ivanprocookie.github.io/iphotos/app/cursors/white/text_trans_rgb.png),auto;");
    /* <!-- Custom Cursors [END] --> */


    /* <!-- Scenes 4 explanation --> */
/* preset scene texts */
var text_1 = "This is made possible with a couple things, shown in these images: (Slider)\n\n\n\n[Block View]\n\n\n[Code View]\n\n\nI first made an array/list with every character my font supports, and I make a string that has the widths-";
var text_2 = "string that has the widths of all of them, so that 2 M's is wider than 3 i's, etc, (It's not monospaced).\nThen, after it gets an input from the input box, it pads it by 13 spaces, to the left. e.g; \"hello\" becomes \"hello        \".\nAfter It has all that, It iterates 'i' from 0-12, and variably* sets each image's  URL, Width and Position:\n• URL: I hosted all images for this app on my Github.\n• Width: It stores the-";
var text_3 = "• Width: It stores the widths of each character you type in the 'lengths' array, so if I start it with an A, the 'lengths' array would start with a 5.\n• Position: It gets the x offset by taking the sum of the widths of every character before it (to the left of it), multiplies it by 4, then it adds the amount of elements before it, (which is conveniently 'i'), and multiplies it by 4 to add the gaps between-";
var text_4 = "4 to add the gaps between each character, & then adds 6, which is the margin.\nI set the margin and widths in such a way that if there are 13 A's it will fit perfectly, (btw, 13 is the length of \"Hello, World!\").\nAlso, this is the PosX formula visualized as a Mathematical Equation:3\n\n[6 + 4(the sum from 'j' equals 0, to 'i' - 1, of 'lengths' sub j) + 4i.svg]";
//setText("explanation", text_1);
// Images: code-view;   block-view;   6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i

var scene = 0;
function setScene(plustwo){
  //scene = (scene + plustwo)%4;  // It loops, don't know if I like that though, buut?
  scene += plustwo; scene = scene<0?0:scene>3?3:scene;  // This doesn't loop, it just clamps the number.
  
  if(scene==0){
    setText("explanation", text_1);
    hideElement('6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i');
    showElement('code-view'); showElement('block-view');
    showElement('slider'); showElement('bar'); setStyle('block-view-img', 'width: '+width+'px;');
    hideElement('github'); setStyle('cursor', 'height: 64px;');
    console.log('  Scene: 1');
  }else if(scene==1){
    setText("explanation", text_2);
    hideElement('code-view'); hideElement('block-view'); hideElement('6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i');
    hideElement('slider'); hideElement('bar'); setStyle('block-view-img', 'width: 0px;');
    showElement('github'); setStyle('cursor', 'height: 85px;');
    console.log('  Scene: 2');
  }else if(scene==2){
    setText("explanation", text_3);
    hideElement('code-view'); hideElement('block-view'); hideElement('6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i');
    hideElement('slider'); hideElement('bar'); setStyle('block-view-img', 'width: 0px;');
    hideElement('github'); setStyle('cursor', 'height: 85px;');
    console.log('  Scene: 3');
  }else if(scene==3){
    setText("explanation", text_4);
    hideElement('code-view'); hideElement('block-view');
    showElement('6+4theSumFromjEquals0_Toi-1_OfLengthsSubj+4i');
    hideElement('slider'); hideElement('bar'); setStyle('block-view-img', 'width: 0px;');
    hideElement('github'); setStyle('cursor', 'height: 85px;');
    console.log('  Scene: 4');
}}

onEvent("scene_selector_3000", "click", function(p){
  if(p.offsetX <= 76/2){
    setScene(-1);
  }else{
    setScene(1);
  }
});

onEvent("github", "click", function(){
  open("https://ivanprocookie.github.io/iphotos/app");
});

/* Image Comparison Slider */
setScreen("how_it_works");
var width = 276; var pos = [22, 138];
                            // background-color: rgba(0,0,0,0.8);
write('<div id="cursor" style="position: fixed; width: 276px; height: 64px; margin-left: 22px; margin-top: 74px; border-radius: 10px; z-index: 42;"></div>');
write('<div id="block-view" style="width: '+width/2+'px; margin-left: '+pos[0]+'px; margin-top: '+pos[1]+'px; pointer-events: none;"><img id="block-view-img" style="margin: 0px; width: '+width+'px; border: 1px solid white; border-radius: 16px; pointer-events: none;" src="https://ivanprocookie.github.io/iphotos/app/scene_images/Small_Test_Block.png"></div>');
setStyle('slider', 'position: absolute; z-index: 2; opacity: 0;'); setProperty("slider","x",pos[0]); setProperty("slider","y",pos[1]); //+138);
setProperty("bar", "x", (pos[0]+width/2)-12); setStyle("bar", "z-index: 1;");
setStyle("title2", "z-index: 100;"); // +92
onEvent("slider","input",function(){
  setStyle('block-view', 'width: '+getProperty("slider", "value")+'px;');
  setProperty("bar", "x", getProperty("slider", "value")+12);
});
setScreen("intro");
/* Image Comp Slider [END] */
    /* <!-- Scenes 4 explanation [END] --> */

cursors();




/* Made By IvanP.      (•̀ω•́)      
._______       _    .__    .____  
|__. ._ \     /.\   |  \   | ._ \ 
   | | \ \   / _ \__| . \__| |_) |
   | |  \ \_/ ___ \_| |\ \_| .__/ 
.__| |___\   /___\ \| |_\ \| |    
|_________\_/_____\___|__\___| :3 
/*   CRYBDgAQBQMIBQsIDw4PFg==   */
